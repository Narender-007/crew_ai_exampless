import os

os.environ["SERPER_API_KEY"] = "bcaaa25c1c4ccfbf6fc8c3ffc189d4fb78c48f28"  # serper.dev API key

os.environ["OPENAI_API_KEY"] = "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"



from crewai import Agent

from crewai_tools import SerperDevTool

search_tool = SerperDevTool()



# Creating a senior researcher agent with memory and verbose mode

researcher = Agent(

  role='Senior Researcher',

  goal='Uncover groundbreaking technologies in {topic}',

  verbose=True,

  memory=True,

  backstory=(

    "Driven by curiosity, you're at the forefront of"

    "innovation, eager to explore and share knowledge that could change"

    "the world."

  ),

  tools=[search_tool],

  allow_delegation=True

)



# Creating a writer agent with custom tools and delegation capability

writer = Agent(

  role='Writer',

  goal='Narrate compelling tech stories about {topic}',

  verbose=True,

  memory=True,

  backstory=(

    "With a flair for simplifying complex topics, you craft"

    "engaging narratives that captivate and educate, bringing new"

    "discoveries to light in an accessible manner."

  ),

  tools=[search_tool],

  allow_delegation=False

)
